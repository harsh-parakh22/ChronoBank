# Import tasks to make them available when importing from app.tasks
from app.tasks.loan_tasks import start_loan_scheduler