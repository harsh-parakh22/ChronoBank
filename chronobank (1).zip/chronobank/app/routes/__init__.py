# Import routes
from app.routes.user_routes import auth_bp
from app.routes.account_routes import account_bp
from app.routes.transaction_routes import transaction_bp
